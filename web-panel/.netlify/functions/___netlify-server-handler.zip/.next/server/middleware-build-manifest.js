globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1ubf55H5GTtvZKR9qZjqS/_buildManifest.js",
    "static/1ubf55H5GTtvZKR9qZjqS/_ssgManifest.js",
    "static/1ubf55H5GTtvZKR9qZjqS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/3450qyhportkm.js",
    "static/chunks/3g4px251sg85e.js",
    "static/chunks/1wei3pmn6euw3.js",
    "static/chunks/turbopack-3yi3gls_lvhfq.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
