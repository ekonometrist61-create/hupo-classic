globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/PgfGd0SBPWTzZ25R3SwVI/_buildManifest.js",
    "static/PgfGd0SBPWTzZ25R3SwVI/_ssgManifest.js",
    "static/PgfGd0SBPWTzZ25R3SwVI/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/3450qyhportkm.js",
    "static/chunks/3g4px251sg85e.js",
    "static/chunks/1wei3pmn6euw3.js",
    "static/chunks/turbopack-3yi3gls_lvhfq.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
