module.exports=[50369,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{children:a})}])},10282,function(a){a.n(a.i(50369))}];

//# sourceMappingURL=src_app_%5Blocale%5D_%28full-width-pages%29_layout_tsx_15qzj09._.js.map