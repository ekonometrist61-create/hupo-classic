module.exports=[34913,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_sorular_toplu-ekle_page_actions_1r8vs_2.js.map