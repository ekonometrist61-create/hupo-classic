module.exports=[57917,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_sorular_page_actions_0xugmm-.js.map