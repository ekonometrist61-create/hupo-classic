module.exports=[78992,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_veli-paneli_page_actions_18tyu1t.js.map