module.exports=[94511,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_siniflar_page_actions_0xjpv8e.js.map