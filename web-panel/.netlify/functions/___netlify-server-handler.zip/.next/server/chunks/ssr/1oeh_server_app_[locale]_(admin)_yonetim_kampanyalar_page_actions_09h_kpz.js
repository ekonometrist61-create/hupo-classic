module.exports=[58526,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_kampanyalar_page_actions_09h_kpz.js.map