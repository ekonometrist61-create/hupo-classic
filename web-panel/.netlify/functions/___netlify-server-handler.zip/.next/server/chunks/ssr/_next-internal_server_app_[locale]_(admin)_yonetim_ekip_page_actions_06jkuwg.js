module.exports=[49209,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_ekip_page_actions_06jkuwg.js.map