module.exports=[73737,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_%28others-pages%29_calendar_page_actions_04m35tf.js.map