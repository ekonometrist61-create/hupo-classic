module.exports=[57606,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_planlar_page_actions_1a9mi-6.js.map