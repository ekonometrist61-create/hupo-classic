module.exports=[73428,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_bildirimler_page_actions_1p8onb9.js.map