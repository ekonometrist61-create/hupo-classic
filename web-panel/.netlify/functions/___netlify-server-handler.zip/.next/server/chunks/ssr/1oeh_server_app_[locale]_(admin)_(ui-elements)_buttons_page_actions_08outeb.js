module.exports=[12606,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_%28ui-elements%29_buttons_page_actions_08outeb.js.map