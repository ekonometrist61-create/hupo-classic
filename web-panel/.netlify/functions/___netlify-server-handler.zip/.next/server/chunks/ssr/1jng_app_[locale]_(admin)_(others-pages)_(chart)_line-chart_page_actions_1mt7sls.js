module.exports=[72242,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%5Blocale%5D_%28admin%29_%28others-pages%29_%28chart%29_line-chart_page_actions_1mt7sls.js.map