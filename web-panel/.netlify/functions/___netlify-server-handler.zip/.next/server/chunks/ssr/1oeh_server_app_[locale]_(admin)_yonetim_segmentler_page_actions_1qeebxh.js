module.exports=[10689,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_segmentler_page_actions_1qeebxh.js.map