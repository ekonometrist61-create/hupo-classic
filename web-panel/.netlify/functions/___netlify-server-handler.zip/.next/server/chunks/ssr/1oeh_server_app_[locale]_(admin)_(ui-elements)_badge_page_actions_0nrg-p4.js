module.exports=[47546,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_%28ui-elements%29_badge_page_actions_0nrg-p4.js.map