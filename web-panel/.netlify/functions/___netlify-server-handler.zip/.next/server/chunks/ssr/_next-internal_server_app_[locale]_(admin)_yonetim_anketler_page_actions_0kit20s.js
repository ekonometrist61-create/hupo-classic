module.exports=[61896,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_anketler_page_actions_0kit20s.js.map