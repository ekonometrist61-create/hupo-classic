module.exports=[65707,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%5Blocale%5D_%28admin%29_%28others-pages%29_%28chart%29_bar-chart_page_actions_1zw0g8w.js.map