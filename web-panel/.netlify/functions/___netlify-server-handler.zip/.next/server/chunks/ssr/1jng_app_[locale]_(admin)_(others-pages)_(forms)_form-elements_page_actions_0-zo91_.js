module.exports=[8170,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%5Blocale%5D_%28admin%29_%28others-pages%29_%28forms%29_form-elements_page_actions_0-zo91_.js.map