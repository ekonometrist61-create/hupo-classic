module.exports=[29580,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_analitik_page_actions_1vd10b3.js.map