module.exports=[89922,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%5Blocale%5D_%28full-width-pages%29_%28error-pages%29_error-404_page_actions_0y0wdgv.js.map