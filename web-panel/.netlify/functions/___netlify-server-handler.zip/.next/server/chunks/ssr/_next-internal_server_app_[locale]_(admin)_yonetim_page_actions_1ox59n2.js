module.exports=[90103,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_page_actions_1ox59n2.js.map