module.exports=[31373,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_veli-adaylari_page_actions_0zz6kkl.js.map