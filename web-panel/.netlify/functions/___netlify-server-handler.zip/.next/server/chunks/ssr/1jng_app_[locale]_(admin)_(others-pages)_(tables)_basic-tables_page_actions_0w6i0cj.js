module.exports=[18205,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%5Blocale%5D_%28admin%29_%28others-pages%29_%28tables%29_basic-tables_page_actions_0w6i0cj.js.map