module.exports=[79232,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_kanal-ayarlari_page_actions_1ewck9b.js.map