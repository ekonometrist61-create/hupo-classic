module.exports=[72984,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_otomasyonlar_page_actions_18c7s3o.js.map