module.exports=[65471,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28student%29_ogrenci_soru_page_actions_1tydn45.js.map