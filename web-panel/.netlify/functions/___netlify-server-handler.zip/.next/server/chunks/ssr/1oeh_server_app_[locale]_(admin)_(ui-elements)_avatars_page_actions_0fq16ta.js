module.exports=[30865,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_%28ui-elements%29_avatars_page_actions_0fq16ta.js.map