module.exports=[72689,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_kuponlar_page_actions_1ve03s3.js.map