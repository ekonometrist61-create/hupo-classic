module.exports=[37294,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28admin%29_yonetim_odemeler_page_actions_12um1ij.js.map