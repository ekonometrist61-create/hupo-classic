module.exports=[15511,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28full-width-pages%29_demo_page_actions_0zjes3g.js.map