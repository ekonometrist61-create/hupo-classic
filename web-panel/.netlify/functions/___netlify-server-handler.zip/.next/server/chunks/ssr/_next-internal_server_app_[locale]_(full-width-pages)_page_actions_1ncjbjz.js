module.exports=[48686,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28full-width-pages%29_page_actions_1ncjbjz.js.map