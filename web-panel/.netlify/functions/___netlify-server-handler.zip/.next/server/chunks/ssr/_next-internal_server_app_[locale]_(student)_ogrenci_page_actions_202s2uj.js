module.exports=[1833,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28student%29_ogrenci_page_actions_202s2uj.js.map