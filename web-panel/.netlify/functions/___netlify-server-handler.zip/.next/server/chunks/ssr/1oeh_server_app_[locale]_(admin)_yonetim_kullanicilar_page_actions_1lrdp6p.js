module.exports=[15774,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%5Blocale%5D_%28admin%29_yonetim_kullanicilar_page_actions_1lrdp6p.js.map